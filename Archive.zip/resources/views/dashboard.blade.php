@extends('layout')
@section('title') {{ config('app.name') }} | {{ $title }} @endsection


@section('content')



@endsection