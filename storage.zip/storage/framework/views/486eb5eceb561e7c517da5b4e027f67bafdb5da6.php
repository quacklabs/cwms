<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-'.$flag)): ?>
        <div class="section-header-button">
            <a class="btn btn-primary" href="<?php echo e(route('transaction.create', ['flag' => $flag])); ?>">Add New</a>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php endif; ?>
        
        <?php echo e(Breadcrumbs::render('transactions.'.$flag)); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Manage <?php echo e(ucwords($flag)); ?></h2>
        <p class="section-lead">
            Unsettled payments are displayed in red.
        </p>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>All <?php echo e($flag); ?>s</h4>
                        <div class="card-header-form">
                            <form>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped ">
                                <thead class="bg-dark text-white">
                                    <tr class="text-left">
                                        <th class="text-white">Invoice | Date</th>
                                        <th class="text-white"><?php echo e(($flag == 'purchase') ? 'Supplier' : 'Customer'); ?> | Mobile</th>
                                        <th class="text-white">Amount | Warehouse</th>
                                        <th class="text-white">Payable | Discount </th>
                                        <th class="text-white">Due | Paid</th>
                                        <th class="text-white">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="mt-4">
                                    <?php if(empty($items)): ?>
                                    <tr>No <?php echo e($flag); ?> found</tr>

                                    <?php else: ?>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-left">
                                            <td>
                                                <strong>#<?php echo e($transaction->invoice_no); ?></strong>
                                                <span class="text-muted">
                                                    <p><?php echo e($transaction->created_at); ?></p>
                                                </span>
                                            </td>

                                            <td class="p-2">
                                                <strong><?php echo e($transaction->owner->name); ?></strong>
                                                <span class="text-muted">
                                                    <p><?php echo e($transaction->owner->mobile_no); ?></p>
                                                </span>
                                            </td>
                                            
                                            <td class="p-3">
                                                <strong>&#8358;<?php echo e(number_format($transaction->total_price, 2)); ?></strong>
                                                <span class="text-muted">
                                                    <p><?php echo e($transaction->warehouse->name); ?></p>
                                                </span>
                                            </td>

                                            <td class="p-3">
                                                <strong>&#8358;<?php echo e(number_format($transaction->payable(), 2)); ?></strong>
                                                <span class="text-muted">
                                                    <p>&#8358;<?php echo e(number_format($transaction->discount_amount, 2)); ?></p>
                                                </span>
                                            </td>

                                            <td>
                                                <strong class="<?php echo e(($transaction->due() == 0.00) ? '' : 'text-danger'); ?>">&#8358;<?php echo e(number_format($transaction->due,2)); ?> </strong>
                                                <span class="text-muted">
                                                    <p>&#8358;<?php echo e(number_format($transaction->paid_amount, 2)); ?></p>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="buttons">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve-'.$flag)): ?>
                                                        <?php if(floatval($transaction->due) > floatval(0.00)): ?>
                                                            <a href="#" id="btn-modal" class="btn btn-dark btn-icon" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?php echo e(($flag == 'purchase') ? 'Give Payment' : 'Receive Payment'); ?>"  data-transaction="<?php echo e(json_encode($transaction)); ?>" >
                                                                <i class="fas fa-money-check-alt" ></i>
                                                            </a>
                                                            <!-- <a href="#" class="btn btn-dark" data-toggle="" > -->
                                                                
                                                            <!-- </a> -->
                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-purchase-return')): ?>
                                                        <a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?php echo e(($flag == 'purchase') ? 'Return Purchase' : 'Return Sale'); ?>">
                                                            <i class="fas fa-reply"></i>
                                                        </a>
                                                    <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-purchase')): ?>
                                                        <a href="" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?php echo e(($flag == 'purchase') ? 'Delete Purchase' : 'Delete Sale'); ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                   

                                    
                            
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="float-right">
                            <?php if(empty($transactions)): ?>

                            <?php else: ?>
                                <?php echo e($items->links()); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.modal-dialog {
  max-width: 50%;
  margin: auto;
}
</style>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content card">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel"><?php echo e(($flag == 'sale') ? 'Receive Payment' : 'Give Payment'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>
            

            <div class="modal-body">
                <form id="moneyForm" method="POST" action="#">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row align-items-center">
                        <label for="site-title" class="form-control-label col-sm-3 text-md-right">Amount</label>
                        <div class="col-sm-6 col-md-9">
                        <input id="amount" name="amount" type="text" class="form-control" id="decimalInput" required>
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <label for="site-description" class="form-control-label col-sm-3 text-md-right">Due Now</label>
                        <div class="col-sm-6 col-md-9">
                            <input id="due" name="due" type="text" class="form-control"  value="" readonly>
                        </div>
                    </div>

                    <div class="form-group row align-items-center">
                        <label for="site-description" class="form-control-label col-sm-3 text-md-right">Signature</label>
                        <div class="col-sm-6 col-md-9">
                            <input id="myCheckbox" name="status" type="checkbox" class="form-control" checked required>
                            <span class="text-muted">I affirm that I have <?php echo e(($flag == 'sale') ? 'received' : 'given'); ?> the sum stated above</span>
                        </div>
                    </div>

                    <div class="form-group row align-items-center">
                        <!-- <label for="site-description" class="form-control-label col-sm-3 text-md-right">Active</label> -->
                        <div class="col-sm-6 col-md-9">
                            <button type="submit" class="btn btn-large btn-primary">Accept</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(function() {

        $("#btn-modal").on('click', function() {
            const details = $(this).data('transaction')
            $("#due").val(details.due.toLocaleString())
            $("#moneyForm").prop('action', details.url)
            $("#myModal").modal('show');
        })
        
    })
</script>

<?php if(empty($edit_product)): ?>

<?php else: ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/transactions/view_transactions.blade.php ENDPATH**/ ?>