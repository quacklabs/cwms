<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-expense')): ?>
        <div class="section-header-button">
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New</button>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php endif; ?>
        
        <?php echo e(Breadcrumbs::render()); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Manage Expenses</h2>
        <!-- <p class="section-lead">
            Each staff must be assigned to a partner
        </p> -->

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>All Expenses</h4>
                        <div class="card-header-form">
                            <form>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th>S.N</th>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Created By</th>
                                        <th>Actions</th>
                                    </tr>

                                    <?php if(empty($types)): ?>

                                    <?php else: ?>
                                        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <tr>
                                            <td>
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td><?php echo e($expense->date); ?></td>
                                            <td>
                                                <?php echo e(ucwords($expense->type->name)); ?>

                                            </td>

                                            <td>
                                                <?php echo e($expense->amount); ?>

                                            </td>

                                            <td>
                                                <?php echo e($expense->staff->name); ?>

                                            </td>
                                            
                                            <td>
                                                <div class="buttons">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-expense')): ?>
                                                        <a href="<?php echo e(route('expense.delete_type', ['id' => $type->id])); ?>" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete Expense Type">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('expense.download', ['id' => $expense->id])); ?>" class="btn btn-icon btn-dark" data-toggle="tooltip" data-placement="top" title="" data-original-title="Download Invoice">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <!-- <a href="#" class="btn btn-icon btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="far fa-user"></i></a>
                                                    <a href="#" class="btn btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-info-circle"></i></a>
                                                    <a href="#" class="btn btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-exclamation-triangle"></i></a>
                                                    <a href="#" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-times"></i></a>
                                                    <a href="#" class="btn btn-icon btn-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-check"></i></a>
                                                    <a href="#" class="btn btn-icon btn-light" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-star"></i></a>
                                                    <a href="#" class="btn btn-icon btn-dark" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="far fa-file"></i></a> -->
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                   

                                    
                            
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="float-right">
                            <?php if(empty($expenses)): ?>

                            <?php else: ?>
                                <?php echo e($expenses->links()); ?>

                            <?php endif; ?>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.modal-dialog {
  max-width: 50%;
  margin: auto;
}
</style>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content card">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Add Expense Type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>
            

            <div class="modal-body">
                <form id="productForm" method="post" action="<?php echo e(route('expense.expenses')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                            
                        <div class="form-group row">
                            <label for="site-title" class="form-control-label text-md-right col-sm-3">Date</label>
                            <div class="col-sm-6 col-md-9">
                            <input name="date" type="text" name="site_title" class="form-control" id="site-title" value="<?php echo e(date('d-m-Y')); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                            
                        <div class="form-group row">
                            <label for="site-title" class="form-control-label text-md-right col-sm-3">Amount</label>
                            <div class="col-sm-6 col-md-9">
                            <input name="amount" type="text" name="site_title" class="form-control" id="site-title" required>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                            
                        <div class="form-group row">
                            <label for="site-title" class="form-control-label text-md-right col-sm-3">Expense Type</label>
                            <div class="col-sm-6 col-md-9">
                            <select class="form-control" name="type_id">
                                <?php if(empty($types)): ?>
                                
                                <?php else: ?>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>"> <?php echo e($type->name); ?></option>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-lg">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/expense/expenses.blade.php ENDPATH**/ ?>