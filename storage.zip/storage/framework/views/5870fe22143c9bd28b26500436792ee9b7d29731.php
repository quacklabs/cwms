<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transfer-product')): ?>
        <div class="section-header-button">
            <a class="btn btn-primary" href="<?php echo e(route('transfer.create')); ?>">Add New</a>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php endif; ?>
        
        <?php echo e(Breadcrumbs::render('transfer.transfers')); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Manage Transfers</h2>
        <p class="section-lead">
            
        </p>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>All Transfers</h4>
                        <div class="card-header-form">
                            <form>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped ">
                                <thead class="bg-dark text-white">
                                    <tr class="text-left">
                                        <th class="text-white">S.N</th>
                                        <th class="text-white">Tracking No</th>
                                        <th class="text-white">From</th>
                                        <th class="text-white">To </th>
                                        <th class="text-white">Products</th>
                                        <th class="text-white">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="mt-4">
                                    <?php if(empty($transfers)): ?>
                                    <tr>
                                        <td colspan="6">No transfers found</td>
                                    </tr>

                                    <?php else: ?>
                                        <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-left">
                                            <td>
                                                <strong>#<?php echo e($loop->iteration); ?></strong>
                                            </td>
                                            <td>
                                                <?php echo e($transfer->tracking_no); ?>

                                            </td>

                                            <td>
                                                <?php echo e($transfer->source_warehouse->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($transfer->destination_warehouse->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($transfer->totalProducts); ?>

                                            </td>
                                            <td>
                                                <a href="#" id="btn-modal" class="btn btn-dark btn-icon" data-toggle="tooltip" data-placement="top" title="" data-original-title="Download Invoice"  data-transaction="Download Invoice">
                                                    <i class="fas fa-download" ></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                   

                                    
                            
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="float-right">
                            <?php if(empty($transfers)): ?>

                            <?php else: ?>
                                <?php echo e($transfers->links()); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(function() {

        $("#btn-modal").on('click', function() {
            const details = $(this).data('transaction')
            $("#due").val(details.due.toLocaleString())
            $("#moneyForm").prop('action', details.url)
            $("#myModal").modal('show');
        })
        
    })
</script>

<?php if(empty($edit_product)): ?>

<?php else: ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/transfer/transfers.blade.php ENDPATH**/ ?>