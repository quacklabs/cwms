<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-product')): ?>
        <div class="section-header-button">
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New</button>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php endif; ?>
        
        <?php echo e(Breadcrumbs::render('product.products')); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Manage Products</h2>
        <!-- <p class="section-lead">
            Each staff must be assigned to a warehouse
        </p> -->

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>All Products</h4>
                        <div class="card-header-form">
                            <form>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name|SKU</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Stock</th>
                                        <th>Total Sale | Alert Qty</th>
                                        <th>Unit</th>
                                        <th>Actions</th>
                                    </tr>

                                    <?php if(empty(@products)): ?>
                                    
                                    <?php else: ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="p-0 text-center">
                                                <img src="image;base64,<?php echo e($product->image); ?>" style="height: 80px; width: 80px;">
                                            </td>
                                            <td>
                                                <?php echo e($product->name); ?>

                                                <span class="text-muted">
                                                    <p><?php echo e($product->sku); ?></p>
                                                </span>
                                            </td>
                                            <td class="p-3">
                                                <?php echo e($product->brands->name); ?>

                                            </td>
                                            <td class="p-3">
                                            <?php echo e($product->categories->name); ?>

                                            </td>
                                            <td><?php echo e($product->totalInStock()); ?></td>
                                            <td class="p-3">
                                                <?php echo e($product->totalSale()); ?>

                                                <span class="text-muted">
                                                    <p><?php echo e($product->alert); ?> <?php echo e($product->unit->name); ?></p>
                                                </span>
                                            </td>
                                            <td><?php echo e($product->unit->name); ?></td>
                                            <td><a href="#" class="btn btn-secondary">Detail</a></td>
                                        </tr>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    
                            
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="float-right">
                            <?php if(empty($products)): ?>

                            <?php else: ?>
                                <?php echo e($products->links()); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.modal-dialog {
  max-width: 70%;
  margin: auto;
}
</style>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content card">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Add product</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>
            

            <div class="modal-body">
                <form id="productForm" method="post" action="<?php echo e(route('product.products')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">Product Name</label>
                                <input id="productName" name="name" type="text" class="form-control" autocomplete="off" required>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">SKU</label>
                                <input id="sku" name="sku" type="text" class="form-control" autocomplete="off" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <!-- <div class="form-group col-6 col-sm-12">
                                <label for="inputEmail4"></label>
                                <input id="productName" name="name" type="text" class="form-control" autocomplete="off" required>
                            </div> -->

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">Category</label>
                                <select class="form-control" name="category_id">
                                    <?php if(empty(@categories)): ?>
                                    <option>No Categories</option>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e(ucwords($category->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">Unit</label>
                                <select class="form-control" name="unit_id">
                                    <?php if(empty(@units)): ?>
                                    <option>No Units</option>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($unit->id); ?>"><?php echo e(strtoupper($unit->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">Brand Name</label>
                                <select class="form-control" name="brand_id">
                                    <?php if(empty(@brands)): ?>
                                    <option>No Brands</option>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"><?php echo e(ucwords($brand->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">Alert Amount</label>
                                <input id="productName" name="alert" type="number" class="form-control" autocomplete="off" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6 col-sm-12">
                                <label for="inputEmail4">Image</label>
                                <input name="image" type="file" class="form-control">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12 col-sm-12">
                                <label for="inputEmail4">Notes</label>
                                <textarea class="form-control" name="notes">

                                </textarea>
                            </div>
                        </div>
                        
                        
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-lg">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<?php if(empty($edit_product)): ?>

<?php else: ?>
<script>
    // $(function() {
    //     $("#myModalLabel").html('Edit product')
    //     const form = $("#productForm")
    //     $("#productName").val("<?php echo e($edit_product->name); ?>")

    //     var newAction = "<?php echo e(route('product.edit', ['type' => 'edit_product', 'id' => $product->id])); ?>" 
    //     console.log(newAction); // Verify the newAction value in the console
    //     form.attr('action', newAction);
        
    //     $(".close").click(function(e) {
    //         e.preventDefault()
    //         window.location.href = "<?php echo e(route('product.products')); ?>"
    //     });

    //     $("#myModal").modal('show')
    // })
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/product/products.blade.php ENDPATH**/ ?>