<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('adjust-stock')): ?>
        <div class="section-header-button">
            <a href="<?php echo e(route('stock.make_adjustment')); ?>" class="btn btn-primary">Add New</a>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php endif; ?>
        
        <?php echo e(Breadcrumbs::render('stock.adjustment')); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Adjust Products Stock</h2>
        <!-- <p class="section-lead">
            Each staff must be assigned to a warehouse
        </p> -->

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>All Products</h4>
                        <div class="card-header-form">
                            <form>
                                <div class="row">
                                    <div class="col-5">
                                        <input type="text" class="form-control" placeholder="Start Date">
                                    </div>
                                    <div class="col-5">
                                        <input type="text" class="form-control" placeholder="End Date">
                                    </div>
                                    <div class="col-2">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
                                    </div>


                                </div>
                                
                            </form>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.N</th>
                                        <th>Tracking No</th>
                                        <th>Date</th>
                                        <th>Warehouse</th>
                                        <th>Products</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(empty($adjustments)): ?>


                                    <?php else: ?>
                                        <?php $__currentLoopData = $adjustments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e(strtoupper($adjustment->tracking_no)); ?> </td>
                                                <td><?php echo e($adjustment->adjust_date); ?></td>
                                                <td><?php echo e($adjustment->warehouse->name); ?></td>
                                                <td><?php echo e(count($adjustment->details)); ?></td>
                                                <td>
                                                    <div class="buttons">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-adjustment')): ?>
                                                        <a href="<?php echo e(route('stock.adjustment', ['id' => $adjustment->id])); ?>" class="btn btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(route('stock.download_invoice', ['id' => $adjustment->id])); ?>" class="btn btn-icon btn-dark" data-toggle="tooltip" data-placement="top" title="" data-original-title="Download Invoice">
                                                            <i class="fas fa-download"></i>
                                                        </a>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-adjustment')): ?>
                                                        <a href="<?php echo e(route('stock.delete_adjustment', ['id' => $adjustment->id])); ?>" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                        <?php endif; ?>

                                                    </div>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="float-right">
                            
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<?php if(empty($edit_product)): ?>

<?php else: ?>
<script>
   
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/product/adjustments.blade.php ENDPATH**/ ?>