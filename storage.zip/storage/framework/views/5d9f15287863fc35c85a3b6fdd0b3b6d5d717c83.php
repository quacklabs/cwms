<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo e($title); ?></h1>
            
            <?php echo e(Breadcrumbs::render('transactions.enter_'.$flag.'_ledger')); ?>

        </div>
        <div class="section-body">
            <h2 class="section-title">Invoice #<?php echo e($transaction->invoice_no); ?></h2>
            <p class="section-lead">
                generate a new payment receipt
            </p>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        
            <div class="row mt-4">
                <div class="col-lg-9 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                        <h4><?php echo e($title); ?></h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('transaction.enter_ledger', ['flag' => $flag, 'id' => $transaction->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row align-items-center">
                                    <label for="site-title" class="form-control-label col-sm-3 text-md-right">Amount</label>
                                    <div class="col-sm-6 col-md-9">
                                    <input name="amount" type="text" class="form-control" id="decimalInput" required>
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="site-description" class="form-control-label col-sm-3 text-md-right">Due Now</label>
                                    <div class="col-sm-6 col-md-9">
                                        <input name="due" type="text" class="form-control"  value="<?php echo e(number_format($transaction->due(),2)); ?>" readonly>
                                    </div>
                                </div>

                                <div class="form-group row align-items-center">
                                    <label for="site-description" class="form-control-label col-sm-3 text-md-right">Signature</label>
                                    <div class="col-sm-6 col-md-9">
                                        <input id="myCheckbox" name="status" type="checkbox" class="form-control" checked required>
                                        <span class="text-muted">I affirm that I have <?php echo e($action); ?> said sum above</span>
                                    </div>
                                </div>

                                <div class="form-group row align-items-center">
                                    <!-- <label for="site-description" class="form-control-label col-sm-3 text-md-right">Active</label> -->
                                    <div class="col-sm-6 col-md-9">
                                        <button type="submit" class="btn btn-large btn-primary">Accept</button>
                                    </div>
                                </div>
                            </form>
                             
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script>
    $(function() {

        $('form').on('submit', function(event) {
            if (!$('#myCheckbox').is(':checked')) {
                event.preventDefault();
                swal({
                    title: 'Signature Required',
                    text: "Please check affirmation box",
                    icon: 'warning'
                })
            }
        });

        $('#decimalInput').on('input', function() {
            var inputValue = $(this).val();
            var cursorPosition = $(this).prop('selectionStart');
            var key = event.originalEvent.data;

            if (key === '.' && inputValue.includes('.')) {
                // Prevent entering multiple decimal points
                event.preventDefault();
            } else {
            // Remove non-digit characters
                var numericValue = inputValue.replace(/[^0-9.]/g, '');
                var formattedValue = parseFloat(numericValue).toFixed(2);

                // Update the input value with the formatted value
                $(this).val(formattedValue);

                // Adjust the cursor position
                var newPosition = cursorPosition;

                if (key === '.' && cursorPosition <= inputValue.indexOf('.')) {
                    // Move the cursor after the decimal point
                    newPosition += 1;
                } else if (cursorPosition > inputValue.indexOf('.')) {
                    // Adjust cursor position when input length changes
                    newPosition += (formattedValue.length - inputValue.length);
                }

                $(this).prop('selectionStart', newPosition);
                $(this).prop('selectionEnd', newPosition);
            }
        });
    })
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/transactions/enter_ledger.blade.php ENDPATH**/ ?>