<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- General CSS Files -->       
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/iziToast.css')); ?>">

        <?php echo $__env->yieldContent('css'); ?>
    
    </head>
    <body>
        <div id="app">
            <?php if(auth()->guard()->check()): ?>
            <div class="main-wrapper main-wrapper-1">
                <!-- Content for authenticated users -->
                <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
            <div class="">
            <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>

                <footer class="main-footer">
                    <div class="footer-left">
                    Copyright &copy; <?php echo e(date('Y')); ?>

                    </div>
                    <div class="footer-right">
                    All Rights Reserved
                    </div>
                </footer>
            </div>
        </div>

        <!-- General JS Scripts -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
        <script src="<?php echo e(asset('js/popper.js')); ?>"></script>
        <script src="<?php echo e(asset('js/tooltip.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/stisla.js')); ?>"></script>
        <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

        <?php if(session('success')): ?>
        <script>
            $(function() {
                swal({
                title: 'Successful',
                text: "<?php echo e(session('success')); ?>",
                icon: 'success'
                })
            })
        </script>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <script>
            $(function() {
                swal({
                title: 'Successful',
                text: "<?php echo e(session('error')); ?>",
                icon: 'warning'
                })
            })
        </script>
<?php endif; ?>
        
        <?php echo $__env->yieldContent('js'); ?>

        <!-- Template JS File -->
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    </body>
</html>



<?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/layout.blade.php ENDPATH**/ ?>