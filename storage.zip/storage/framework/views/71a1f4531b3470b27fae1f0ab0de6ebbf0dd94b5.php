<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <div class="section-header-button">
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New</button>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php echo e(Breadcrumbs::render('product.categories')); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Manage Product Categories</h2>
        <!-- <p class="section-lead">
            Each staff must be assigned to a warehouse
        </p> -->

        
        <div class="row mt-4">
            <div class="col-12">
            <div class="card">
                <div class="card-header">
                <h4>All Categories</h4>
                </div>
                <div class="card-body">
                <div class="clearfix mb-3"></div>

                <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>                                 
                          <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Products</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>   
                            <?php if(empty($categories)): ?>

                            <?php else: ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td class="pricing-item">
                                        <?php if($cat->status == true): ?>
                                        <div class="pricing-details">
                                            <div class="pricing-item">
                                                <div class="pricing-item-icon bg-success text-white px-1" style="border-radius: 50%; height: 20px; width: 20px;">
                                                    <i class="fas fa-check"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <?php else: ?>
                                        <div class="pricing-details">
                                            <div class="pricing-item">
                                                <div class="pricing-item-icon bg-warning text-white px-1" style="border-radius: 50%; height: 20px; width: 20px;">
                                                    <i class="fas fa-times"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </td>

                                    <td class="pricing-item">
                                        <?php echo e($cat->name); ?>

                                    </td>

                                    <td class="pricing-item">
                                        <?php echo e($cat->product_count); ?>

                                    </td>
                        
                                    <td>
                                    <div class="buttons">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suspend-category')): ?>
                                            <?php if($cat->status == true): ?>
                                            <a href="<?php echo e(route('product.toggle', ['type' => 'toggle_category', 'id' => $cat->id, 'action' => 'suspend'])); ?>" class="btn btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="Deactivate Category">
                                                <i class="fas fa-times"></i>
                                            </a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('product.toggle', ['type' => 'toggle_category', 'id' => $cat->id, 'action' => 'activate'])); ?>" class="btn btn-icon btn-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Activate Category">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <?php endif; ?>

                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modify-category')): ?>
                                        <a href="<?php echo e(route('product.edit', ['type' => 'edit_category', 'id' => $cat->id])); ?>" class="btn btn-icon btn-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit Category">
                                            <i class="far fa-edit"></i>
                                        </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-category')): ?>
                                        <a href="<?php echo e(route('product.delete', ['type' => 'delete_category', 'id' => $cat->id])); ?>" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete Category">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <?php endif; ?>
                                        


                                        <!-- <a href="#" class="btn btn-icon btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="far fa-user"></i></a>
                                        <a href="#" class="btn btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-info-circle"></i></a>
                                        <a href="#" class="btn btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-exclamation-triangle"></i></a>
                                        <a href="#" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-times"></i></a>
                                        <a href="#" class="btn btn-icon btn-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-check"></i></a>
                                        <a href="#" class="btn btn-icon btn-light" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-star"></i></a>
                                        <a href="#" class="btn btn-icon btn-dark" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="far fa-file"></i></a> -->
                                    </div>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                <div class="float-right">
                <?php if(empty($categories)): ?>

                <?php else: ?>
                    <?php echo e($categories->links()); ?>

                <?php endif; ?>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </section>
</div>

<style>
.modal-dialog {
  max-width: 50%;
  margin: auto;
}
</style>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content card">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Add Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>

            <div class="modal-body">
                <form id="categoryForm" method="post" action="<?php echo e(route('product.categories')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="inputEmail4">Category Name</label>
                                <input id="categoryName" name="name" type="text" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                        
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-lg">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php if(empty($category)): ?>

<?php else: ?>
<script>
    $(function() {
        $("#myModalLabel").html('Edit Category')
        const form = $("#categoryForm")
        $("#categoryName").val("<?php echo e($category->name); ?>")

        var newAction = "<?php echo e(route('product.edit', ['type' => 'edit_category', 'id' => $category->id])); ?>" 
        console.log(newAction); // Verify the newAction value in the console
        form.attr('action', newAction);
        
        $(".close").click(function(e) {
            e.preventDefault()
            window.location.href = "<?php echo e(route('product.categories')); ?>"
        });

        $("#myModal").modal('show')
    })
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/product/categories.blade.php ENDPATH**/ ?>