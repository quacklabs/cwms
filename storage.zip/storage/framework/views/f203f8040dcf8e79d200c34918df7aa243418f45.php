<?php $__env->startSection('title'); ?> <?php echo e(config('app.name')); ?> | <?php echo e($title); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
        <h1><?php echo e($title); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-warehouse')): ?>
        <div class="section-header-button">
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New</button>
            <!-- <a href="#" class="btn btn-primary">Add New</a> -->
        </div>
        <?php endif; ?>
        <?php echo e(Breadcrumbs::render('warehouse.warehouse')); ?>

        </div>
        <div class="section-body">
        <h2 class="section-title">Manage warehouses</h2>
        <p class="section-lead">
            Manage warehouse details
        </p>

        
        <div class="row mt-4">
            <div class="col-12">
            <div class="card">
                <div class="card-header">
                <h4>All warehouses</h4>
                </div>
                <div class="card-body">
                <div class="clearfix mb-3"></div>

                <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>                                 
                          <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Manager</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>   
                            <?php if(empty($warehouses)): ?>

                            <?php else: ?>
                                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td class="pricing-item">
                                        <?php if($warehouse->status == true): ?>
                                        <div class="pricing-details">
                                            <div class="pricing-item">
                                                <div class="pricing-item-icon bg-success text-white px-1" style="border-radius: 50%; height: 20px; width: 20px;">
                                                    <i class="fas fa-check"></i>
                                                </div>
                                            </div>
                                        </div>

                                        <?php else: ?>
                                        <div class="pricing-item-icon bg-danger text-white px-1" style="border-radius: 50%; height: 20px; width: 20px;">
                                            <i class="fas fa-times"></i>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($warehouse->name); ?></td>
                                    <td><?php echo e($warehouse->address); ?></td>
                                    <td><?php echo e($warehouse->manager->name ?? 'Unassigned'); ?></td>
                                    <td>
                                        <div class="buttons">
                                            <a href="<?php echo e(route('warehouse.view', ['id' => $warehouse->id])); ?>" class="btn btn-icon btn-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="View Warehouse">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suspend-warehouse')): ?>
                                                <?php if($warehouse->status == true): ?>
                                                <a href="<?php echo e(route('warehouse.toggle', ['id' => $warehouse->id, 'action' => 'suspend'])); ?>" class="btn btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="Deactivate Warehouse">
                                                    <i class="fas fa-times"></i>
                                                </a>
                                                <?php else: ?>
                                                <a href="<?php echo e(route('warehouse.toggle', ['id' => $warehouse->id, 'action' => 'activate'])); ?>" class="btn btn-icon btn-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Activate Warehouse">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reassign-manager')): ?>
                                            <a href="<?php echo e(route('warehouse.reassign', ['id' => $warehouse->id])); ?>" class="btn btn-icon btn-dark" data-toggle="tooltip" data-placement="top" title="" data-original-title="Reassign Manager">
                                                <i class="fas fa-random"></i>
                                            </a>
                                            <?php endif; ?>

                                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                                <a href="<?php echo e(route('warehouse.edit', ['id' => $warehouse->id])); ?>" class="btn btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit Warehouse">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modify-warehouse')): ?>
                                                <?php if($warehouse->manager_id == $user->id): ?>
                                                <a href="<?php echo e(route('warehouse.edit', ['id' => $warehouse->id])); ?>" class="btn btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit Warehouse">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php else: ?>
                                                    
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-warehouse')): ?>
                                                <a href="<?php echo e(route('warehouse.delete', ['id' => $warehouse->id])); ?>" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete Warehouse">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                            <!-- <a href="#" class="btn btn-icon btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="far fa-user"></i></a>
                                            <a href="#" class="btn btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-info-circle"></i></a>
                                            <a href="#" class="btn btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-exclamation-triangle"></i></a>
                                            <a href="#" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-times"></i></a>
                                            <a href="#" class="btn btn-icon btn-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-check"></i></a>
                                            <a href="#" class="btn btn-icon btn-light" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="fas fa-star"></i></a>
                                            <a href="#" class="btn btn-icon btn-dark" data-toggle="tooltip" data-placement="top" title="" data-original-title="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><i class="far fa-file"></i></a> -->
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                <div class="float-right">
                    <?php echo e($warehouses->links()); ?>

                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </section>
</div>

<style>
.modal-dialog {
  max-width: 70%;
  margin: 1.75rem auto;
}
</style>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content card">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Add warehouse</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>

            <div class="modal-body">
                <form method="post" action="<?php echo e(route('warehouse.all_warehouses')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="inputEmail4">Name</label>
                                <input name="name" type="text" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="inputEmail4">Address</label>
                                <input name="address" type="text" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/celdon/resources/views/warehouse/warehouses.blade.php ENDPATH**/ ?>